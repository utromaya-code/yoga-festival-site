# 📦 Пакет для дизайнера — YogaFest 2026

## 🎨 Цветовая палитра

### Основные цвета
| Название | HEX | RGB | Использование |
|----------|-----|-----|---------------|
| Sage (Шалфей) | `#8B9D83` | 139, 157, 131 | Иконки, акценты |
| Sage Dark | `#5C6B55` | 92, 107, 85 | Секция отзывов, preloader |
| Terracotta (Терракота) | `#C67B5C` | 198, 123, 92 | CTA кнопки, акценты |
| Terracotta Light | `#E8A98A` | 232, 169, 138 | Градиенты |
| Sand (Песок) | `#E6DDD1` | 230, 221, 209 | Фон секций |
| Cream (Кремовый) | `#FAF8F5` | 250, 248, 245 | Основной фон |
| Charcoal (Уголь) | `#2C2C2C` | 44, 44, 44 | Текст, футер |
| Gold (Золото) | `#BFA265` | 191, 162, 101 | Акценты, бейджи |

### CSS переменные
```css
--sage: #8B9D83;
--sage-dark: #5C6B55;
--terracotta: #C67B5C;
--terracotta-light: #E8A98A;
--sand: #E6DDD1;
--cream: #FAF8F5;
--charcoal: #2C2C2C;
--gold: #BFA265;
```

---

## 🔤 Типографика

### Шрифты
| Тип | Шрифт | Google Fonts |
|-----|-------|--------------|
| Заголовки | **Cormorant Garamond** | [Ссылка](https://fonts.google.com/specimen/Cormorant+Garamond) |
| Текст | **Space Grotesk** | [Ссылка](https://fonts.google.com/specimen/Space+Grotesk) |

### Размеры
| Элемент | Desktop | Mobile |
|---------|---------|--------|
| H1 (Hero) | 120px | 48px |
| H2 (Секции) | 56px | 36px |
| H3 (Карточки) | 28px | 24px |
| Body | 17px | 16px |
| Caption/Label | 12px | 11px |

### Стили текста
- **Labels**: uppercase, letter-spacing: 4px, font-weight: 600
- **Цитаты**: italic, font-family: serif
- **CTA кнопки**: uppercase, letter-spacing: 1-2px, font-weight: 600

---

## 🖼️ Изображения

### Hero (главный экран)
**Текущее**: Женщина в позе дерева на фоне гор
- https://images.unsplash.com/photo-1545389336-cf090694435e

**Альтернативы**:
1. Групповая йога на рассвете
   - https://images.unsplash.com/photo-1506126613408-eca07ce68773
2. Медитация у озера
   - https://images.unsplash.com/photo-1518611012118-696072aa579a
3. Йога на деревянной террасе (Бали стиль)
   - https://images.unsplash.com/photo-1544367567-0f2fcb009e0b

### About секция
**Текущее**: Силуэт йоги на закате
- https://images.unsplash.com/photo-1544367567-0f2fcb009e0b

### Experience карточки
1. **Рассветные практики** — медитация на рассвете
   - https://images.unsplash.com/photo-1506126613408-eca07ce68773
2. **Медитации** — поза лотоса в лесу
   - https://images.unsplash.com/photo-1545205597-3d9d02c29597
3. **Мастер-классы** — групповая практика
   - https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7
4. **Вечера у костра** — костёр/свечи
   - https://images.unsplash.com/photo-1599901860904-17e6ed7083a0

### Video секция
**Фон**: Медитация с закатом
- https://images.unsplash.com/photo-1518611012118-696072aa579a

### Location
**Фон**: Озеро с лесом
- https://images.unsplash.com/photo-1523913710015-0a4c60c840e3

### Учителя (placeholder)
Заменить на реальные фото:
- https://images.unsplash.com/photo-1594744803329-e58b31de8bf5
- https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d
- https://images.unsplash.com/photo-1438761681033-6461ffad8d80
- https://images.unsplash.com/photo-1472099645785-5658abf4ff4e

---

## 📐 Структура блоков

### 1. Hero (100vh)
- Полноэкранное фото/видео
- Overlay градиент (сверху вниз, прозрачный → тёмный)
- Лого слева, CTA справа
- Дата + локация (метка)
- Заголовок (3 строки, "Йога" золотом курсивом)
- Философская цитата
- Кнопка "Смотреть видео"
- Scroll indicator внизу по центру

### 2. Rating Bar (белый фон)
- ★★★★★ 500+ отзывов
- #1 Йога-ретрит в России
- 5 000+ участников за 10 лет

### 3. Philosophy (Three Pillars)
- 3 карточки в ряд (1 на мобильном)
- Иконка в круге (gradient sage)
- Заголовок + подзаголовок (EN)
- Описание

### 4. About (Split section)
- 50/50 фото | текст
- Parallax эффект на фото
- Stats: 10+ | 50+ | 5000+

### 5. Marquee
- Бегущая строка на чёрном фоне
- Направления йоги через точки

### 6. Experience (4 карточки)
- Aspect ratio 3:4
- Hover: zoom фото
- Overlay с названием внизу

### 7. Video Section (80vh)
- Фоновое фото
- Большая кнопка play по центру
- Цитата под кнопкой

### 8. Schedule
- Табы по дням (1-4)
- Список: время | название | учитель
- Hover: подсветка строки

### 9. Teachers (4 колонки)
- Фото с pill-shaped рамкой (закруглённое сверху)
- Grayscale → color при hover
- Имя + специализация

### 10. Testimonials (carousel)
- Тёмный sage фон
- Большая цитата по центру
- Фото + имя автора
- Точки навигации

### 11. Pricing (3 карточки)
- Basic (светлый), Popular (тёмный), VIP (terracotta gradient)
- Badge "Популярный" на средней
- Цена крупно
- Список features
- CTA кнопка

### 12. FAQ (accordion)
- Вопрос + иконка "+"
- Ответ раскрывается при клике
- Только один открыт одновременно

### 13. Location
- Фото на фоне с градиентом слева
- Текст слева
- Иконки с контактами

### 14. CTA Banner
- Terracotta фон
- Заголовок + текст + кнопка

### 15. Footer
- 4 колонки на desktop
- Лого, соцсети, навигация, контакты
- Copyright внизу

---

## 🎬 Анимации

### Scroll Reveal
- Элементы появляются снизу (translateY: 40px → 0)
- Opacity: 0 → 1
- Duration: 0.8s
- Easing: cubic-bezier(0.16, 1, 0.3, 1)

### Hover эффекты
- Кнопки: scale(1.05) или фон меняется
- Карточки: translateY(-12px) + shadow
- Изображения: scale(1.1) за 0.6s
- Ссылки: подчёркивание появляется слева направо

### Progress Bar
- Линия вверху страницы
- Ширина = % прокрутки
- Gradient: terracotta → gold

### Preloader
- Sage-dark фон
- Лого + loading bar
- Исчезает через 1.5s

### Marquee
- Бесконечная прокрутка влево
- Duration: 40s linear

### Testimonials Carousel
- Fade transition между слайдами
- Auto-rotate каждые 5s

---

## 📱 Breakpoints

| Устройство | Ширина |
|------------|--------|
| Desktop | > 1200px |
| Tablet | 768px - 1200px |
| Mobile | < 768px |
| Small Mobile | < 400px |

### Мобильные адаптации
- Hamburger меню вместо навигации
- Одноколоночные layouts
- Уменьшенные шрифты
- Sticky CTA внизу (опционально)
- Touch-friendly кнопки (min 44px)

---

## 📁 Файлы проекта

```
yoga-festival-site/
├── index.html          # Основной HTML с inline CSS/JS
├── README.md           # Описание проекта
├── DESIGNER_PACKAGE.md # Этот файл
└── assets/             # (создать для изображений)
    ├── images/
    └── fonts/
```

---

## 🔗 Ссылки

- **Live сайт**: https://utromaya-code.github.io/yoga-festival-site/
- **GitHub репозиторий**: https://github.com/utromaya-code/yoga-festival-site
- **Google Fonts**: 
  - [Cormorant Garamond](https://fonts.google.com/specimen/Cormorant+Garamond)
  - [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk)
- **Unsplash коллекции**:
  - [Yoga](https://unsplash.com/s/photos/yoga)
  - [Meditation](https://unsplash.com/s/photos/meditation)
  - [Retreat](https://unsplash.com/s/photos/retreat)

---

## ✅ Чеклист для Tilda

1. Создать проект в Tilda
2. Добавить Custom CSS (цвета, шрифты)
3. Собрать страницу из Zero Block
4. Вставить HTML/CSS из index.html
5. Подключить Google Fonts
6. Настроить мобильную версию
7. Добавить формы оплаты
8. Опубликовать

---

*Создано: Январь 2026*
*Версия: 3.0*
