# 🧘 Летний Йога-Фестиваль 2026

Креативный landing page для летнего йога-фестиваля.

## 🌐 Демо

[Смотреть сайт](https://utromaya-code.github.io/yoga-festival-site/) · [Репозиторий](https://github.com/utromaya-code/yoga-festival-site)

## ✨ Особенности

- Уникальный креативный дизайн
- Современная типографика (Unbounded + Inter)
- Яркая палитра цветов заката
- Плавные анимации
- Полностью адаптивный
- Готов для Zero Block (Tilda)

## 🎨 Дизайн

- **Шрифты:** Unbounded (заголовки), Inter (текст)
- **Цвета:** Sunset Orange, Forest Green, Sage
- **Стиль:** Креативный минимализм

## 📁 Структура

```
yoga-festival-site/
├── index.html    # Весь сайт в одном файле
└── README.md     # Документация
```

## 🚀 Использование

### Локально
Просто откройте `index.html` в браузере.

### GitHub Pages
1. Создайте репозиторий на GitHub
2. Загрузите файлы
3. Settings → Pages → Branch: main
4. Сайт будет доступен по ссылке

### Tilda (Zero Block)
1. Скопируйте содержимое `index.html`
2. В Tilda добавьте Zero Block
3. Вставьте код в HTML режим

## 📝 Лицензия

MIT

---

*Создано с любовью к йоге* 🧘‍♀️