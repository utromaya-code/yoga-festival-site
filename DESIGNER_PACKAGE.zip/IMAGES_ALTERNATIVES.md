# 🖼️ Альтернативные изображения для YogaFest

## Hero — Главный экран

### Вариант 1 (текущий) — Поза дерева в горах
![](https://images.unsplash.com/photo-1545389336-cf090694435e?w=1920&q=80)
```
https://images.unsplash.com/photo-1545389336-cf090694435e?w=1920&q=80
```

### Вариант 2 — Медитация на террасе (Бали)
![](https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1920&q=80)
```
https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1920&q=80
```

### Вариант 3 — Силуэт йоги на закате
![](https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1920&q=80)
```
https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1920&q=80
```

### Вариант 4 — Групповая практика на природе
![](https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=1920&q=80)
```
https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=1920&q=80
```

### Вариант 5 — Медитация у воды
![](https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1920&q=80)
```
https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1920&q=80
```

---

## Experience карточки

### Рассветные практики
```
https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&q=80
```
**Альтернатива:**
```
https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80
```

### Медитации
```
https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=800&q=80
```
**Альтернатива:**
```
https://images.unsplash.com/photo-1508672019048-805c876b67e2?w=800&q=80
```

### Мастер-классы
```
https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?w=800&q=80
```
**Альтернатива:**
```
https://images.unsplash.com/photo-1588286840104-8957b019727f?w=800&q=80
```

### Вечера у костра
```
https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=800&q=80
```
**Альтернатива (костёр):**
```
https://images.unsplash.com/photo-1475483768296-6163e08872a1?w=800&q=80
```

---

## Секция "О фестивале"

### Вариант 1 (текущий)
```
https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1200&q=85
```

### Вариант 2 — Йога на деревянном помосте
```
https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=1200&q=85
```

### Вариант 3 — Лотос у воды
```
https://images.unsplash.com/photo-1508672019048-805c876b67e2?w=1200&q=85
```

---

## Video Section (фон)

### Вариант 1 (текущий)
```
https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1920&q=80
```

### Вариант 2 — Закат в горах
```
https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=1920&q=80
```

### Вариант 3 — Туманный лес
```
https://images.unsplash.com/photo-1448375240586-882707db888b?w=1920&q=80
```

---

## Location (место проведения)

### Вариант 1 (текущий) — Озеро с лесом
```
https://images.unsplash.com/photo-1523913710015-0a4c60c840e3?w=1920&q=80
```

### Вариант 2 — Деревянный дом у озера
```
https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?w=1920&q=80
```

### Вариант 3 — Горное озеро
```
https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=1920&q=80
```

---

## Галерея (дополнительные фото)

1. Групповая йога на траве
```
https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800&q=80
```

2. Поющие чаши
```
https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?w=800&q=80
```

3. Свечи и благовония
```
https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80
```

4. Коврики для йоги
```
https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80
```

5. Здоровое питание
```
https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80
```

---

## Placeholder для учителей

*Заменить на реальные фотографии преподавателей*

```
Мария: https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=600&q=80
Алексей: https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80
Елена: https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&q=80
Дмитрий: https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=600&q=80
```

---

## Как скачать изображения

1. Открой ссылку в браузере
2. Правый клик → "Сохранить изображение как..."
3. Или используй параметры URL:
   - `?w=1920` — ширина 1920px
   - `?w=800` — ширина 800px
   - `?q=80` — качество 80%
   - `&fit=crop` — обрезка по размеру

**Пример для скачивания в высоком разрешении:**
```
https://images.unsplash.com/photo-1545389336-cf090694435e?w=2400&q=90
```

---

*Все изображения с Unsplash — бесплатны для коммерческого использования*
